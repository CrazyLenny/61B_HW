package edu.berkeley.cs.cs61b.hw.hw8.list;

/* QueueEmptyException.java */

//package list;

public class QueueEmptyException extends Exception {

  public QueueEmptyException() {
    super();
  }

  public QueueEmptyException(String s) {
    super(s);
  }

}
