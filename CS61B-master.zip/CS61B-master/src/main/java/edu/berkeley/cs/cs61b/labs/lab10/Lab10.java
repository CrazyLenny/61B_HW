package edu.berkeley.cs.cs61b.labs.lab10;

public class Lab10 {

}
